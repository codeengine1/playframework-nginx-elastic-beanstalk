#!/bin/bash

set -xe

/opt/elasticbeanstalk/containerfiles/generate_config.py
